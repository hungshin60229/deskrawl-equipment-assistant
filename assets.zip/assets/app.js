'use strict';
const $=id=>document.getElementById(id);
const token=new URLSearchParams(location.hash.slice(1)).get('token')||'';
let catalog=null,latest=null,editing={slot:'',primary:[],secondary:[]},active={slot:'',primary:[],secondary:[]},picking='primary',lastRender='';
function request(path){return fetch(path,{headers:{'X-Assistant-Token':token},cache:'no-store'}).then(r=>{if(!r.ok)throw Error('連線失敗');return r.json();});}
function el(tag,className,text){const e=document.createElement(tag);if(className)e.className=className;if(text!=null)e.textContent=text;return e;}
function label(stat){return catalog.stat_names[stat]||stat;}
function pool(group){if(editing.slot)return catalog.pools[editing.slot]?.[group]||[];return [...new Set(Object.values(catalog.pools).flatMap(p=>p[group]))];}
function save(){fetch('/api/filters',{method:'POST',headers:{'X-Assistant-Token':token,'Content-Type':'application/json'},body:JSON.stringify(active)}).catch(()=>{});}
function chips(){for(const group of ['primary','secondary']){const parent=$(group+'-chips');parent.replaceChildren();for(const stat of editing[group]){const b=el('button','chip',label(stat));b.append(el('span','','×'));b.setAttribute('aria-label','移除'+label(stat));b.onclick=()=>{editing[group]=editing[group].filter(x=>x!==stat);chips();};parent.append(b);}}$('pending').textContent=JSON.stringify(editing)!==JSON.stringify(active)?'條件已變更，按篩選套用':'';}
function pickerOptions(){const parent=$('options');parent.replaceChildren();const q=$('search').value.trim();for(const stat of pool(picking).filter(x=>label(x).includes(q)||x.toLowerCase().includes(q.toLowerCase()))){const wrap=el('label','option');const check=el('input');check.type='checkbox';check.value=stat;check.checked=editing[picking].includes(stat);check.onchange=()=>{if(check.checked)editing[picking].push(stat);else editing[picking]=editing[picking].filter(x=>x!==stat);$('selected-count').textContent='已選擇 '+editing[picking].length+' 個詞條';chips();};wrap.append(check,el('span','',label(stat)));parent.append(wrap);}if(!parent.children.length)parent.append(el('p','','此部位沒有可選的詞條'));$('selected-count').textContent='已選擇 '+editing[picking].length+' 個詞條';}
function openPicker(group){picking=group;$('picker-title').textContent=group==='primary'?'選擇主要詞條':'選擇次要詞條';$('search').value='';pickerOptions();$('picker').showModal();$('search').focus();}
function matches(row){return (!window.buildFavoritesOnly||window.buildFavorites?.includes(row.uid))&&(!active.slot||row.slot===active.slot)&&active.primary.every(s=>row.primary.some(m=>m.stat===s))&&active.secondary.every(s=>row.secondary.some(m=>m.stat===s));}
function affixes(mods,selected){const box=el('div','affixes');if(!mods.length)box.append(el('span','item-meta','—'));for(const m of mods){const line=el('div','affix'+(selected.includes(m.stat)?' matched':'')+(window.preferredStats?.includes(m.stat)?' preferred-affix':''));line.append(el('span','',m.name),el('span','value',m.display));box.append(line);}return box;}
function render(){if(!latest||!catalog)return;const signature=JSON.stringify([latest.revision,latest.status,active,window.buildFavorites,window.buildFavoritesOnly,window.preferredStats]);if(signature===lastRender)return;lastRender=signature;const rows=latest.items.filter(matches).sort((a,b)=>b.level-a.level||a.name.localeCompare(b.name)||a.uid.localeCompare(b.uid));$('count').textContent=rows.length+' 件';const box=$('rows');const expanded=new Set([...box.querySelectorAll('details[open]')].map(x=>x.dataset.uid));box.replaceChildren();for(const row of rows){const card=el('article','equipment-row row-grid');card.dataset.uid=row.uid;const identity=el('div','identity');const icon=el('div','icon');if(row.icon){const img=el('img');img.src=row.icon;img.alt='';icon.append(img);}else icon.append(el('span','fallback','◇'));const names=el('div');names.append(el('div','item-name',row.name),el('div','item-meta','傳奇'+(row.ancient?' · 遠古':'')+(row.black_mist?' · 黑霧':'')+(row.upgrade?' · 強化 +'+row.upgrade:'')));if(row.other.length){const detail=el('details');detail.dataset.uid=row.uid;detail.open=expanded.has(row.uid)||row.other.some(m=>window.preferredStats?.includes(m.stat));detail.append(el('summary','','其他屬性 '+row.other.length+' 條'),affixes(row.other,[]));names.append(detail);}if(window.buildStar)names.prepend(window.buildStar(row));identity.append(icon,names);const position=el('div','position');position.append(el('span','location '+row.location,{equipped:'穿戴中',inventory:'背包',storage:'倉庫'}[row.location]),el('small','',row.position_label));card.append(identity,el('div','level',row.level),affixes(row.primary,active.primary),affixes(row.secondary,active.secondary),position);box.append(card);}$('empty').hidden=rows.length>0;$('empty').textContent=latest.status==='connected'?'沒有符合條件的傳奇裝備，試試減少詞條條件。':'等待遊戲進入角色後，裝備會自動出現。';box.classList.toggle('stale',latest.status!=='connected');}
async function tick(){try{latest=await request('/api/state');$('status').textContent=latest.status==='connected'?'已連接遊戲':latest.status==='offline'?'遊戲未啟動':latest.status==='version'?'需要更新':'等待同步';$('status').className='badge '+latest.status;const hero={MageHero:'法師',HunterHero:'獵人',BarbarianHero:'戰士',MonkHero:'武僧'};$('character').textContent=latest.character?latest.character.level+' 級 '+(hero[latest.character.hero]||latest.character.hero)+(latest.character.mode===1?' · 線上角色':' · 本機角色'):'等待角色載入';$('sync').textContent=latest.updated_at?'每秒自動同步 · 最近讀取 '+latest.updated_at.slice(11):'每秒自動同步';$('notice').hidden=latest.status==='connected';$('notice').textContent=latest.message+(latest.items.length?'；下方為上次成功讀取的資料，尚未同步。':'');if(window.refreshBuilds)await window.refreshBuilds();render();}catch{$('status').textContent='小助手已停止';$('status').className='badge';$('notice').hidden=false;$('notice').textContent='連線中斷。請重新開啟桌面破壞神小助手。下方清單為先前資料。';$('rows').classList.add('stale');}setTimeout(tick,1000);}
async function init(){try{catalog=await request('/api/catalog');for(const [key,name] of Object.entries(catalog.slots)){$('slot').append(new Option(name,key));}try{const saved=await request('/api/filters');if(saved&&Array.isArray(saved.primary)&&Array.isArray(saved.secondary)){active={slot:catalog.slots[saved.slot]?saved.slot:'',primary:saved.primary.filter(x=>catalog.stat_names[x]),secondary:saved.secondary.filter(x=>catalog.stat_names[x])};editing=structuredClone(active);}}catch{}$('slot').value=editing.slot;chips();$('slot').onchange=()=>{editing.slot=$('slot').value;editing.primary=editing.primary.filter(x=>pool('primary').includes(x));editing.secondary=editing.secondary.filter(x=>pool('secondary').includes(x));chips();};$('choose-primary').onclick=()=>openPicker('primary');$('choose-secondary').onclick=()=>openPicker('secondary');$('search').oninput=pickerOptions;$('picker-close').onclick=$('picker-done').onclick=()=>$('picker').close();$('apply').onclick=()=>{active=structuredClone(editing);save();chips();render();};$('clear').onclick=()=>{active={slot:'',primary:[],secondary:[]};editing=structuredClone(active);$('slot').value='';save();chips();render();};$('quit').onclick=async()=>{if(!confirm('結束小助手？遊戲會繼續執行。'))return;await fetch('/api/quit',{method:'POST',headers:{'X-Assistant-Token':token}});$('status').textContent='小助手已停止';};await tick();}catch{$('notice').hidden=false;$('notice').textContent='無法連接小助手，請從桌面破壞神小助手.exe 啟動。';}}
init();

const maintenanceButton=el('button','quiet','小助手設定');maintenanceButton.id='maintenance-open';
$('quit').before(maintenanceButton);
const hideButton=el('button','quiet','收到右下角');hideButton.id='hide-window';$('quit').before(hideButton);
hideButton.onclick=()=>fetch('/api/hide',{method:'POST',headers:{'X-Assistant-Token':token}}).catch(()=>{});
let maintenancePolling=false;
function sizeLabel(value){return (value/1024/1024).toFixed(2)+' MB';}
async function maintenanceRefresh(){
 try{
  const info=await request('/api/maintenance');const busy=['checking','downloading','preparing','restarting','removing'].includes(info.status);
  $('assistant-version').textContent='目前版本 v'+info.version;
  $('update-message').textContent=info.message;
  $('update-start').disabled=busy||!info.can_manage;
  $('uninstall-start').disabled=busy||!info.can_manage;
  $('update-cancel').hidden=!['checking','downloading','preparing'].includes(info.status);
  $('update-progress').hidden=!['downloading','preparing','restarting'].includes(info.status);
  $('update-progress').value=info.download_bytes?Math.min(100,info.downloaded/info.download_bytes*100):100;
  $('update-size').textContent=info.total_bytes?'下載 '+sizeLabel(info.downloaded)+' / '+sizeLabel(info.download_bytes)+' · 完整版本 '+sizeLabel(info.total_bytes)+' · 重用本機內容 '+Math.max(0,Math.round((1-info.download_bytes/info.total_bytes)*100))+'%':'';
  if(!info.can_manage)$('update-message').textContent='請從免安裝版執行檔使用更新與刪除功能。';
 }catch{if($('maintenance-picker').open)$('update-message').textContent='小助手正在關閉或重新啟動，請等待新視窗。';}
}
async function maintenancePoll(){await maintenanceRefresh();if(maintenancePolling)setTimeout(maintenancePoll,500);}
maintenanceButton.onclick=()=>{$('maintenance-picker').showModal();if(!maintenancePolling){maintenancePolling=true;maintenancePoll();}};
$('maintenance-close').onclick=()=>$('maintenance-picker').close();
$('maintenance-picker').addEventListener('close',()=>{maintenancePolling=false;});
async function maintenanceAction(path){
 const response=await fetch(path,{method:'POST',headers:{'X-Assistant-Token':token}});
 if(!response.ok){const info=await response.json();throw Error(info.error||'操作無法完成');}
 await maintenanceRefresh();
}
$('update-start').onclick=async()=>{
 $('update-start').disabled=true;
 try{await maintenanceAction('/api/update');}catch(error){$('update-message').textContent=error.message;$('update-start').disabled=false;}
};
$('update-cancel').onclick=async()=>{try{await maintenanceAction('/api/update/cancel');}catch(error){$('update-message').textContent=error.message;}};
$('uninstall-start').onclick=async()=>{
 if(!confirm('確定完全刪除桌面破壞神小助手？\n\n小助手、所有收藏圖片、篩選條件、裝備紀錄與小助手版本備份都會刪除，無法復原。\n遊戲與遊戲存檔不受影響。'))return;
 $('uninstall-start').disabled=true;
 try{await maintenanceAction('/api/uninstall');}catch(error){$('update-message').textContent=error.message;$('uninstall-start').disabled=false;}
};
async function avatarGallery(){
 const data=await request('/api/avatars');const gallery=$('avatar-gallery');gallery.replaceChildren();
 for(const item of data.images){
  const button=el('button','avatar-choice'+(item.id===data.selected?' selected':''));const img=el('img');img.src=item.url;img.alt=item.name;
  button.append(img,el('span','',item.name+(item.id===data.selected?' ✓':'')));
  button.onclick=async()=>{
   button.disabled=true;
   try{const response=await fetch('/api/avatar/select',{method:'POST',headers:{'X-Assistant-Token':token,'Content-Type':'application/json'},body:JSON.stringify({id:item.id})});if(!response.ok)throw Error('無法切換圖片');$('avatar').src='/avatar.png?v='+Date.now();await avatarGallery();$('avatar-picker-status').textContent='已切換，重新開啟也會保留';}
   catch(error){$('avatar-picker-status').textContent=error.message;button.disabled=false;}
  };
  const card=el('div','avatar-tile');card.append(button);
  if(item.id!=='default'){
   const remove=el('button','avatar-delete','刪除圖片');remove.setAttribute('aria-label','刪除'+item.name);
   remove.onclick=async()=>{
    if(!confirm('確定刪除這張收藏圖片？'+(item.id===data.selected?'目前頭像將換回預設貓咪。':'')))return;
    remove.disabled=true;
    try{const response=await fetch('/api/avatar/delete',{method:'POST',headers:{'X-Assistant-Token':token,'Content-Type':'application/json'},body:JSON.stringify({id:item.id})});if(!response.ok)throw Error('無法刪除圖片');$('avatar').src='/avatar.png?v='+Date.now();await avatarGallery();$('avatar-picker-status').textContent='圖片已刪除';}
    catch(error){$('avatar-picker-status').textContent=error.message;remove.disabled=false;}
   };card.append(remove);
  }else card.append(el('span','avatar-protected','固定保留'));
  gallery.append(card);
 }
}
$('avatar-button').onclick=$('change-avatar').onclick=async()=>{try{await avatarGallery();$('avatar-picker-status').textContent='圖片保存在本機';$('avatar-picker').showModal();}catch(error){$('avatar-message').hidden=false;$('avatar-message').textContent='無法載入圖片收藏：'+error.message;}};
$('avatar-picker-close').onclick=()=>$('avatar-picker').close();
$('upload-avatar').onclick=()=>$('avatar-file').click();
$('avatar-file').onchange=async()=>{
 const input=$('avatar-file'),file=input.files[0];if(!file)return;
 const msg=$('avatar-message');msg.hidden=false;msg.textContent='正在儲存圖片…';
 try{
  if(file.size>8*1024*1024)throw Error('請選擇 8 MB 以內的圖片。');
  const bitmap=await createImageBitmap(file);const canvas=document.createElement('canvas');
  const scale=Math.min(1,512/Math.max(bitmap.width,bitmap.height));canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
  const data=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!data)throw Error('無法讀取這張圖片。');
  const response=await fetch('/api/avatar',{method:'POST',headers:{'X-Assistant-Token':token,'Content-Type':'image/png'},body:data});
  if(!response.ok){const error=await response.json();throw Error(error.error||'儲存失敗');}
  $('avatar').src='/avatar.png?v='+Date.now();await avatarGallery();$('avatar-picker-status').textContent='已加入收藏並切換圖片';msg.textContent='圖片已加入收藏，之後可直接選擇切換。';setTimeout(()=>{msg.hidden=true;},3500);
 }catch(error){msg.textContent='無法更換圖片：'+error.message;}finally{input.value='';}
};
